﻿using System;
using System.Collections.Generic;
using System.Text;
using Server;
using System.Collections;
using System.IO;
using Server.Items;

namespace Bittiez.TutAi
{
    public class Miner49 : TutAiBase
    {
        private string path = Directory.GetCurrentDirectory() + "\\Scripts\\Customs\\TutAi";
        private string filename = "questions.csv";

        public Miner49(Serial serial)
            : base(serial)
        {
        }

        [Constructable]
        public Miner49()
            : base()
        {
            InitStats(100, 100, 25);
            Title = "the miner";

            Hue = Utility.RandomSkinHue();

            if (!Core.AOS)
                NameHue = 0x35;
            this.Body = 0x190;
            this.Name = NameList.RandomName("male");

            AddItem(new Shirt(Utility.RandomOrangeHue()));

            Item skirt;

            switch (Utility.Random(2))
            {
                case 0: skirt = new FullApron(); break;
                default:
                case 1: skirt = new HalfApron(); break;
            }

            skirt.Hue = Utility.RandomNeutralHue();

            AddItem(skirt);

            AddItem((Item)(new LongPants(Utility.RandomNeutralHue())));

            AddItem((Item)(new Pickaxe()));


            Item boots;

            switch (Utility.Random(2))
            {
                case 0: boots = new Boots(); break;
                default:
                case 1: boots = new ThighBoots(); break;
            }

            AddItem(boots);

            Utility.AssignRandomHair(this);

            load_csv(filename, path);
            Start_Timer(TimeSpan.FromSeconds(1.0));
        }

        public override void Timer_Callback()
        {
            int r = new Random().Next(2);
            switch (r)
            {
                case 0: this.Move(random_direction()); break;
                case 1: this.Animate(11, 7, new Random().Next(5), true, false, 0); break;
            }
            base.Start_Timer(TimeSpan.FromSeconds(1.0));
        }

        private Direction random_direction()
        {
            while (true)
            {
                switch (new Random().Next(8))
                {
                    case 0: return Direction.East;
                    case 1: return Direction.Down;
                    case 2: return Direction.Left;
                    case 3: return Direction.North;
                    case 4: return Direction.Right;
                    case 5: return Direction.South;
                    case 6: return Direction.Up;
                    case 7: return Direction.West;
                }
            }
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);
            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);
            int version = reader.ReadInt();
            load_csv(filename, path);
            Start_Timer(TimeSpan.FromSeconds(2.0));
        }
    }
}
