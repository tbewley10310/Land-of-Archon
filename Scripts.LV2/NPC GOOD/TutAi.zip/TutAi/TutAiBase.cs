using Server;
using Server.Commands;
using System.Threading;
using System.Web;
using Server.Items;
using System;
using System.Collections;
using System.IO;
using Server.Misc;


namespace Bittiez.TutAi
{

    public class TutAiBase : Mobile
    {
        public ArrayList question;
        //public virtual string SAVEPATH { get; set; }
        //public virtual string FILENAME { get; set; }

        public TutAiBase(Serial serial)
            : base(serial)
        {
        }

        public TutAiBase()
        {
        }


        public override void OnDoubleClick(Mobile from)
        {
            base.OnDoubleClick(from);
            //if (from.AccessLevel > AccessLevel.Player)
            //{
            //    question = new ArrayList();
            //    load_csv();
            //}
        }

        public override bool HandlesOnSpeech(Mobile from)
        {
            if (from.Alive && InRange(from, 4))
                return true;
            return base.HandlesOnSpeech(from);
        }

        public override void OnSpeech(SpeechEventArgs e)
        {
            if (e.Mobile.Alive && InRange(e.Mobile, 4))
            {
                ThinkIt(e.Speech);
            }
        }

        public virtual void Start_Timer(TimeSpan s)
        {
            Server.Timer.DelayCall(s, new Server.TimerCallback(Timer_Callback));
        }


        public virtual void Timer_Callback()
        {
        }

        public override bool CanBeDamaged()
        {
            return false;
        }

        public virtual void ThinkIt(string s)
        {
            string[] q_split, s_by = { "++" };
            bool breaK = false;
            if (question != null)
            {
                foreach (question_info q in question)
                {
                    q_split = q.QEUSTION.Split(s_by, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string q_key in q_split)
                    {
                        if (s.Contains(q_key))
                        {
                            string[] rep = { "{NL}" };
                            string getanswer = q.get_answer() + "{NL}";
                            string[] answer = getanswer.Split(rep, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string sayit in answer)
                            {
                                this.Say(sayit);
                            }
                            breaK = true;
                            break;
                        }
                    }
                    if (breaK)
                        break;
                }
            }
        }

        public virtual void load_csv(string FILENAME, string SAVEPATH)
        {
            ArrayList a;
            if (FILENAME != null && SAVEPATH != null && FILENAME != "" && SAVEPATH != "" && FILENAME != "-" && SAVEPATH != "-")
            {
                if (!File.Exists(Path.Combine(SAVEPATH, FILENAME)))
                {
                    this.Say("Couldn't find " + FILENAME + " file at: " + Path.Combine(SAVEPATH, FILENAME));
                    //DirectoryInfo s = Directory.CreateDirectory(SavePath);
                }
                else
                {
                    question = new ArrayList();
                    string file = File.ReadAllText(Path.Combine(SAVEPATH, FILENAME));
                    string[] c = { "," }, nl = { "\n" }; ;
                    string[] question_infos = file.Split(nl, StringSplitOptions.RemoveEmptyEntries), question_answers;

                    foreach (string q_data in question_infos)
                    {
                        question_answers = q_data.Split(c, StringSplitOptions.RemoveEmptyEntries);
                        string q_n = question_answers[0];
                        a = new ArrayList();
                        bool first = true;
                        foreach (string q_a in question_answers)
                        {
                            if (first)
                            {
                                first = false;
                                continue;
                            }
                            a.Add(q_a);
                        }

                        question.Add(new question_info(q_n, a));
                    }
                }
            }
            else this.Say("Error");
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);
        }




    }

    public class question_info
    {
        public string QEUSTION { get { return text; } set { text = value; } }
        public ArrayList ANSWERS { get { return answers; } set { answers = value; } }
        private string text;
        private ArrayList answers;

        public question_info(string txt)
        {
            text = txt;
        }
        public question_info(string txt, ArrayList a)
        {
            text = txt;
            answers = a;
        }
        public question_info(string txt, string[] a)
        {
            text = txt;
            answers = new ArrayList();
            foreach (string aa in a)
            {
                answers.Add(a);
            }
        }

        public string get_answer()
        {
            int ran = new Random().Next(answers.Count);
            string s = (string)answers[ran];
            s = s.Replace(";;", ",");
            return s;
        }
    }

}